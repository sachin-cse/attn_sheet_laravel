<?php
    $attn_status = [
        1 => '#e8fdeb',
        2 => '#FFCCCB'
    ];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HTML Table</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">


<style>
    table {
        font-family: arial, sans-serif;
        border-collapse: collapse;
        width: 100%;
    }

    td, th {
        border: 1px solid #dddddd;
        text-align: left;
        padding: 8px;
    }

    tr:nth-child(even) {
        background-color: #dddddd;
    }
</style>
    
</head>
<body style="display: grid;min-height: 100vh;">
   <div class="">
    <h2 style="text-align:center;">Attendance - June 2025</h2>
       
    <table>
        <thead>
            <tr>
                <th class="sticky name">Name</th>
                <!-- Day headers: June 1 is Sunday in 2025 -->
                <?php
                $year = 2025;
                $month = 6;
                $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $month, $year);
    
                for($days = 1; $days <= $daysInMonth; $days++){
                    $date = DateTime::createFromFormat('Y-n-j', "$year-$month-$days");
                    $weekday = $date->format('D');
                    ?>
                        <th class="sticky"><?= $weekday; ?><br><?= $days; ?></th>
                    <?php
                }
                ?>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td class="name">Alice</td>
                <td class="present" style="color:#155724; background-color: #e8fdeb;">P</td>
                <td class="absent" style="color:#FF0000; background-color: #FFCCCB;">A</td>
            </tr>
        </tbody>
    </table>

   </div>

<div style="width:600px; margin: auto 0 20px auto;">
<h3 style="text-align:center; margin-top: 40px;">Monthly Attendance Summary – June 2025</h3>

<table style="width:100%; margin: 0; border-collapse: collapse;" border="1">
    <thead>
        <tr>
            <th>Name</th>
            <th>Total Present(In Days)</th>
            <th>Total Absent(In Days)</th>
            <th>CL Allotted(In Month)</th>
            <th>CL Remaining(In Month)</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Alice</td>
            <td>24</td>
            <td>6</td>
            <td>2</td>
            <td>0</td>
        </tr>
        <tr>
            <td>Bob</td>
            <td>26</td>
            <td>4</td>
            <td>2</td>
            <td>0</td>
        </tr>
    </tbody>
</table>
</div>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js"></script>

</body>
</html>
